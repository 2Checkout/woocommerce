<?php

require_once '../../../vendor/autoload.php';
require_once  '../../../wp-load.php';
WP_Mock::bootstrap();
require_once 'src/Twocheckout/Helpers/class-convert-plus-helper.php';
