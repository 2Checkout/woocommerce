<?php

require_once __DIR__ . '/../../../bootstrap.php';

class TwoCheckoutIpnHelperTest extends \WP_Mock\Tools\TestCase {

	/**
	 * @var Two_Checkout_Ipn_Helper
	 */
	public $valid_ipn_helper_test_class;

	/**
	 * @var Two_Checkout_Ipn_Helper
	 */
	public $invalid_ipn_helper_test_class;

	public $params_valid_ipn_mock
		= [
			'GIFT_ORDER'                  => '0',
			'SALEDATE'                    => '2020-08-04 16:37:50',
			'PAYMENTDATE'                 => '0000-00-00 00:00:00',
			'REFNO'                       => '129611332',
			'REFNOEXT'                    => '80',
			'ORIGINAL_REFNOEXT'           => [
				0 => '',
			],
			'SHOPPER_REFERENCE_NUMBER'    => '',
			'ORDERNO'                     => '0',
			'ORDERSTATUS'                 => 'PENDING',
			'PAYMETHOD'                   => 'Visa/MasterCard',
			'PAYMETHOD_CODE'              => 'CCVISAMC',
			'FIRSTNAME'                   => 'John',
			'LASTNAME'                    => 'Doe',
			'COMPANY'                     => '',
			'REGISTRATIONNUMBER'          => '',
			'FISCALCODE'                  => '',
			'TAX_OFFICE'                  => '',
			'CBANKNAME'                   => '',
			'CBANKACCOUNT'                => '',
			'ADDRESS1'                    => 'Dimitrie Pompeiu 10A',
			'ADDRESS2'                    => '',
			'CITY'                        => 'Bucharest',
			'STATE'                       => 'B',
			'ZIPCODE'                     => '020337',
			'COUNTRY'                     => 'Romania',
			'COUNTRY_CODE'                => 'ro',
			'PHONE'                       => '+40770789899',
			'FAX'                         => '',
			'CUSTOMEREMAIL'               => 'cosmin.panait@2checkout.com',
			'FIRSTNAME_D'                 => 'John',
			'LASTNAME_D'                  => 'Doe',
			'COMPANY_D'                   => '',
			'ADDRESS1_D'                  => 'Dimitrie Pompeiu 10A',
			'ADDRESS2_D'                  => '',
			'CITY_D'                      => 'Bucharest',
			'STATE_D'                     => 'B',
			'ZIPCODE_D'                   => '020337',
			'COUNTRY_D'                   => 'Romania',
			'COUNTRY_D_CODE'              => 'ro',
			'PHONE_D'                     => '+40770789899',
			'EMAIL_D'                     => 'cosmin.panait@2checkout.com',
			'IPADDRESS'                   => '127.0.0.1',
			'IPCOUNTRY'                   => '',
			'COMPLETE_DATE'               => '0000-00-00 00:00:00',
			'TIMEZONE_OFFSET'             => 'GMT+03:00',
			'CURRENCY'                    => 'EUR',
			'LANGUAGE'                    => 'en',
			'ORDERFLOW'                   => 'REGULAR',
			'IPN_PID'                     => [
				0 => '31126410',
			],
			'IPN_PNAME'                   => [
				0 => 'Woocomerce 2CO connector',
			],
			'IPN_PCODE'                   => [
				0 => '',
			],
			'IPN_EXTERNAL_REFERENCE'      => [
				0 => '',
			],
			'IPN_INFO'                    => [
				0 => '',
			],
			'IPN_QTY'                     => [
				0 => '1',
			],
			'IPN_PRICE'                   => [
				0 => '10.00',
			],
			'IPN_VAT'                     => [
				0 => '0.00',
			],
			'IPN_VAT_RATE'                => [
				0 => '0.00',
			],
			'IPN_VER'                     => [
				0 => '1',
			],
			'IPN_DISCOUNT'                => [
				0 => '0.00',
			],
			'IPN_PROMONAME'               => [
				0 => '',
			],
			'IPN_PROMOCODE'               => [
				0 => '',
			],
			'IPN_ORDER_COSTS'             => [
				0 => '0',
			],
			'IPN_SKU'                     => [
				0 => '',
			],
			'IPN_PARTNER_CODE'            => '',
			'IPN_PGROUP'                  => [
				0 => '0',
			],
			'IPN_PGROUP_NAME'             => [
				0 => '',
			],
			'MESSAGE_ID'                  => '250447182633',
			'MESSAGE_TYPE'                => 'PENDING',
			'IPN_LICENSE_PROD'            => [
				0 => '31126410',
			],
			'IPN_LICENSE_TYPE'            => [
				0 => 'REGULAR',
			],
			'IPN_LICENSE_REF'             => [
				0 => '',
			],
			'IPN_LICENSE_EXP'             => [
				0 => '',
			],
			'IPN_LICENSE_START'           => [
				0 => '',
			],
			'IPN_LICENSE_LIFETIME'        => [
				0 => 'NO',
			],
			'IPN_LICENSE_ADDITIONAL_INFO' => [
				0 => '',
			],
			'IPN_DELIVEREDCODES'          => [
				0 => '',
			],
			'IPN_DOWNLOAD_LINK'           => '',
			'IPN_TOTAL'                   => [
				0 => '10.00',
			],
			'IPN_TOTALGENERAL'            => '10.00',
			'IPN_SHIPPING'                => '0.00',
			'IPN_SHIPPING_TAX'            => '0.00',
			'AVANGATE_CUSTOMER_REFERENCE' => '',
			'EXTERNAL_CUSTOMER_REFERENCE' => '',
			'IPN_PARTNER_MARGIN_PERCENT'  => '0.00',
			'IPN_PARTNER_MARGIN'          => '0.00',
			'IPN_EXTRA_MARGIN'            => '0.00',
			'IPN_EXTRA_DISCOUNT'          => '0.00',
			'IPN_COUPON_DISCOUNT'         => '0.00',
			'IPN_LINK_SOURCE'             => 'WOOCOMMERCE_3_8',
			'IPN_ORIGINAL_LINK_SOURCE'    => [
				0 => '',
			],
			'IPN_COMMISSION'              => '0.50',
			'REFUND_TYPE'                 => '',
			'CHARGEBACK_RESOLUTION'       => 'NONE',
			'CHARGEBACK_REASON_CODE'      => '',
			'TEST_ORDER'                  => '0',
			'IPN_ORDER_ORIGIN'            => 'API',
			'FRAUD_STATUS'                => 'PENDING',
			'CARD_TYPE'                   => 'Visa',
			'CARD_LAST_DIGITS'            => '1111',
			'CARD_EXPIRATION_DATE'        => '',
			'GATEWAY_RESPONSE'            => '',
			'IPN_DATE'                    => '20200804163753',
			'FX_RATE'                     => '1.125696',
			'FX_MARKUP'                   => '4',
			'PAYABLE_AMOUNT'              => '10.69',
			'PAYOUT_CURRENCY'             => 'USD',
			'VENDOR_CODE'                 => '250111206876',
			'PROPOSAL_ID'                 => '',
			'HASH'                        => '0fd2263ec78170040c100d851bf4644c',
		];
	public $params_invalid_ipn_mock
		= [
			'GIFT_ORDER'                  => '0',
			'SALEDATE'                    => '2020-08-04 16:37:50',
			'PAYMENTDATE'                 => '0000-00-00 00:00:00',
			'REFNO'                       => '129611332',
			'REFNOEXT'                    => '80',
			'ORIGINAL_REFNOEXT'           => [
				0 => '',
			],
			'SHOPPER_REFERENCE_NUMBER'    => '',
			'ORDERNO'                     => '0',
			'ORDERSTATUS'                 => 'PENDING',
			'PAYMETHOD'                   => 'Visa/MasterCard',
			'PAYMETHOD_CODE'              => 'CCVISAMC',
			'FIRSTNAME'                   => 'John',
			'LASTNAME'                    => 'Doe',
			'COMPANY'                     => '',
			'REGISTRATIONNUMBER'          => '',
			'FISCALCODE'                  => '',
			'TAX_OFFICE'                  => '',
			'CBANKNAME'                   => '',
			'CBANKACCOUNT'                => '',
			'ADDRESS1'                    => 'Dimitrie Pompeiu 10A',
			'ADDRESS2'                    => '',
			'CITY'                        => 'Bucharest',
			'STATE'                       => 'B',
			'ZIPCODE'                     => '020337',
			'COUNTRY'                     => 'Romania',
			'COUNTRY_CODE'                => 'ro',
			'PHONE'                       => '+40770789899',
			'FAX'                         => '',
			'CUSTOMEREMAIL'               => 'cosmin.panait@2checkout.com',
			'FIRSTNAME_D'                 => 'John',
			'LASTNAME_D'                  => 'Doe',
			'COMPANY_D'                   => '',
			'ADDRESS1_D'                  => 'Dimitrie Pompeiu 10A',
			'ADDRESS2_D'                  => '',
			'CITY_D'                      => 'Bucharest',
			'STATE_D'                     => 'B',
			'ZIPCODE_D'                   => '020337',
			'COUNTRY_D'                   => 'Romania',
			'COUNTRY_D_CODE'              => 'ro',
			'PHONE_D'                     => '+40770789899',
			'EMAIL_D'                     => 'cosmin.panait@2checkout.com',
			'IPADDRESS'                   => '127.0.0.1',
			'IPCOUNTRY'                   => '',
			'COMPLETE_DATE'               => '0000-00-00 00:00:00',
			'TIMEZONE_OFFSET'             => 'GMT+03:00',
			'CURRENCY'                    => 'EUR',
			'LANGUAGE'                    => 'en',
			'ORDERFLOW'                   => 'REGULAR',
			'IPN_PID'                     => [
				0 => '31126410',
			],
			'IPN_PNAME'                   => [
				0 => 'Woocomerce 2CO connector',
			],
			'IPN_PCODE'                   => [
				0 => '',
			],
			'IPN_EXTERNAL_REFERENCE'      => [
				0 => '',
			],
			'IPN_INFO'                    => [
				0 => '',
			],
			'IPN_QTY'                     => [
				0 => '1',
			],
			'IPN_PRICE'                   => [
				0 => '10.00',
			],
			'IPN_VAT'                     => [
				0 => '0.00',
			],
			'IPN_VAT_RATE'                => [
				0 => '0.00',
			],
			'IPN_VER'                     => [
				0 => '1',
			],
			'IPN_DISCOUNT'                => [
				0 => '0.00',
			],
			'IPN_PROMONAME'               => [
				0 => '',
			],
			'IPN_PROMOCODE'               => [
				0 => '',
			],
			'IPN_ORDER_COSTS'             => [
				0 => '0',
			],
			'IPN_SKU'                     => [
				0 => '',
			],
			'IPN_PARTNER_CODE'            => '',
			'IPN_PGROUP'                  => [
				0 => '0',
			],
			'IPN_PGROUP_NAME'             => [
				0 => '',
			],
			'MESSAGE_ID'                  => '250447182633',
			'MESSAGE_TYPE'                => 'PENDING',
			'IPN_LICENSE_PROD'            => [
				0 => '31126410',
			],
			'IPN_LICENSE_TYPE'            => [
				0 => 'REGULAR',
			],
			'IPN_LICENSE_REF'             => [
				0 => '',
			],
			'IPN_LICENSE_EXP'             => [
				0 => '',
			],
			'IPN_LICENSE_START'           => [
				0 => '',
			],
			'IPN_LICENSE_LIFETIME'        => [
				0 => 'NO',
			],
			'IPN_LICENSE_ADDITIONAL_INFO' => [
				0 => '',
			],
			'IPN_DELIVEREDCODES'          => [
				0 => '',
			],
			'IPN_DOWNLOAD_LINK'           => '',
			'IPN_TOTAL'                   => [
				0 => '10.00',
			],
			'IPN_TOTALGENERAL'            => '10.00',
			'IPN_SHIPPING'                => '0.00',
			'IPN_SHIPPING_TAX'            => '0.00',
			'AVANGATE_CUSTOMER_REFERENCE' => '',
			'EXTERNAL_CUSTOMER_REFERENCE' => '',
			'IPN_PARTNER_MARGIN_PERCENT'  => '0.00',
			'IPN_PARTNER_MARGIN'          => '0.00',
			'IPN_EXTRA_MARGIN'            => '0.00',
			'IPN_EXTRA_DISCOUNT'          => '0.00',
			'IPN_COUPON_DISCOUNT'         => '0.00',
			'IPN_LINK_SOURCE'             => 'WOOCOMMERCE_3_8',
			'IPN_ORIGINAL_LINK_SOURCE'    => [
				0 => '',
			],
			'IPN_COMMISSION'              => '0.50',
			'REFUND_TYPE'                 => '',
			'CHARGEBACK_RESOLUTION'       => 'NONE',
			'CHARGEBACK_REASON_CODE'      => '',
			'TEST_ORDER'                  => '0',
			'IPN_ORDER_ORIGIN'            => 'API',
			'FRAUD_STATUS'                => 'PENDING',
			'CARD_TYPE'                   => 'Visa',
			'CARD_LAST_DIGITS'            => '1111',
			'CARD_EXPIRATION_DATE'        => '',
			'GATEWAY_RESPONSE'            => '',
			'IPN_DATE'                    => '20200804163753',
			'FX_RATE'                     => '1.125696',
			'FX_MARKUP'                   => '4',
			'PAYABLE_AMOUNT'              => '10.69',
			'PAYOUT_CURRENCY'             => 'USD',
			'VENDOR_CODE'                 => '250111206876',
			'PROPOSAL_ID'                 => '',
			'HASH'                        => '0fd3263ec78170040c100d851bf4644c',
		];

	public $params_valid_ipn_mock_is_fraud
		= [
			'GIFT_ORDER'                  => '0',
			'SALEDATE'                    => '2020-08-04 16:37:50',
			'PAYMENTDATE'                 => '0000-00-00 00:00:00',
			'REFNO'                       => '129611332',
			'REFNOEXT'                    => '80',
			'ORIGINAL_REFNOEXT'           => [
				0 => '',
			],
			'SHOPPER_REFERENCE_NUMBER'    => '',
			'ORDERNO'                     => '0',
			'ORDERSTATUS'                 => 'PENDING',
			'PAYMETHOD'                   => 'Visa/MasterCard',
			'PAYMETHOD_CODE'              => 'CCVISAMC',
			'FIRSTNAME'                   => 'John',
			'LASTNAME'                    => 'Doe',
			'COMPANY'                     => '',
			'REGISTRATIONNUMBER'          => '',
			'FISCALCODE'                  => '',
			'TAX_OFFICE'                  => '',
			'CBANKNAME'                   => '',
			'CBANKACCOUNT'                => '',
			'ADDRESS1'                    => 'Dimitrie Pompeiu 10A',
			'ADDRESS2'                    => '',
			'CITY'                        => 'Bucharest',
			'STATE'                       => 'B',
			'ZIPCODE'                     => '020337',
			'COUNTRY'                     => 'Romania',
			'COUNTRY_CODE'                => 'ro',
			'PHONE'                       => '+40770789899',
			'FAX'                         => '',
			'CUSTOMEREMAIL'               => 'cosmin.panait@2checkout.com',
			'FIRSTNAME_D'                 => 'John',
			'LASTNAME_D'                  => 'Doe',
			'COMPANY_D'                   => '',
			'ADDRESS1_D'                  => 'Dimitrie Pompeiu 10A',
			'ADDRESS2_D'                  => '',
			'CITY_D'                      => 'Bucharest',
			'STATE_D'                     => 'B',
			'ZIPCODE_D'                   => '020337',
			'COUNTRY_D'                   => 'Romania',
			'COUNTRY_D_CODE'              => 'ro',
			'PHONE_D'                     => '+40770789899',
			'EMAIL_D'                     => 'cosmin.panait@2checkout.com',
			'IPADDRESS'                   => '127.0.0.1',
			'IPCOUNTRY'                   => '',
			'COMPLETE_DATE'               => '0000-00-00 00:00:00',
			'TIMEZONE_OFFSET'             => 'GMT+03:00',
			'CURRENCY'                    => 'EUR',
			'LANGUAGE'                    => 'en',
			'ORDERFLOW'                   => 'REGULAR',
			'IPN_PID'                     => [
				0 => '31126410',
			],
			'IPN_PNAME'                   => [
				0 => 'Woocomerce 2CO connector',
			],
			'IPN_PCODE'                   => [
				0 => '',
			],
			'IPN_EXTERNAL_REFERENCE'      => [
				0 => '',
			],
			'IPN_INFO'                    => [
				0 => '',
			],
			'IPN_QTY'                     => [
				0 => '1',
			],
			'IPN_PRICE'                   => [
				0 => '10.00',
			],
			'IPN_VAT'                     => [
				0 => '0.00',
			],
			'IPN_VAT_RATE'                => [
				0 => '0.00',
			],
			'IPN_VER'                     => [
				0 => '1',
			],
			'IPN_DISCOUNT'                => [
				0 => '0.00',
			],
			'IPN_PROMONAME'               => [
				0 => '',
			],
			'IPN_PROMOCODE'               => [
				0 => '',
			],
			'IPN_ORDER_COSTS'             => [
				0 => '0',
			],
			'IPN_SKU'                     => [
				0 => '',
			],
			'IPN_PARTNER_CODE'            => '',
			'IPN_PGROUP'                  => [
				0 => '0',
			],
			'IPN_PGROUP_NAME'             => [
				0 => '',
			],
			'MESSAGE_ID'                  => '250447182633',
			'MESSAGE_TYPE'                => 'PENDING',
			'IPN_LICENSE_PROD'            => [
				0 => '31126410',
			],
			'IPN_LICENSE_TYPE'            => [
				0 => 'REGULAR',
			],
			'IPN_LICENSE_REF'             => [
				0 => '',
			],
			'IPN_LICENSE_EXP'             => [
				0 => '',
			],
			'IPN_LICENSE_START'           => [
				0 => '',
			],
			'IPN_LICENSE_LIFETIME'        => [
				0 => 'NO',
			],
			'IPN_LICENSE_ADDITIONAL_INFO' => [
				0 => '',
			],
			'IPN_DELIVEREDCODES'          => [
				0 => '',
			],
			'IPN_DOWNLOAD_LINK'           => '',
			'IPN_TOTAL'                   => [
				0 => '10.00',
			],
			'IPN_TOTALGENERAL'            => '10.00',
			'IPN_SHIPPING'                => '0.00',
			'IPN_SHIPPING_TAX'            => '0.00',
			'AVANGATE_CUSTOMER_REFERENCE' => '',
			'EXTERNAL_CUSTOMER_REFERENCE' => '',
			'IPN_PARTNER_MARGIN_PERCENT'  => '0.00',
			'IPN_PARTNER_MARGIN'          => '0.00',
			'IPN_EXTRA_MARGIN'            => '0.00',
			'IPN_EXTRA_DISCOUNT'          => '0.00',
			'IPN_COUPON_DISCOUNT'         => '0.00',
			'IPN_LINK_SOURCE'             => 'WOOCOMMERCE_3_8',
			'IPN_ORIGINAL_LINK_SOURCE'    => [
				0 => '',
			],
			'IPN_COMMISSION'              => '0.50',
			'REFUND_TYPE'                 => '',
			'CHARGEBACK_RESOLUTION'       => 'NONE',
			'CHARGEBACK_REASON_CODE'      => '',
			'TEST_ORDER'                  => '0',
			'IPN_ORDER_ORIGIN'            => 'API',
			'FRAUD_STATUS'                => 'DENIED',
			'CARD_TYPE'                   => 'Visa',
			'CARD_LAST_DIGITS'            => '1111',
			'CARD_EXPIRATION_DATE'        => '',
			'GATEWAY_RESPONSE'            => '',
			'IPN_DATE'                    => '20200804163753',
			'FX_RATE'                     => '1.125696',
			'FX_MARKUP'                   => '4',
			'PAYABLE_AMOUNT'              => '10.69',
			'PAYOUT_CURRENCY'             => 'USD',
			'VENDOR_CODE'                 => '250111206876',
			'PROPOSAL_ID'                 => '',
			'HASH'                        => '0fd2263ec78170040c100d851bf4644c',
		];
	public $secret_key = 'test';

	public $test_order;


	public function setUp(): void {
		$this->test_order = $this->getMockBuilder( WC_Order::class )
			->disableOriginalConstructor()
			->getMock()
		;

		$this->valid_ipn_helper_test_class   = new Two_Checkout_Ipn_Helper( $this->params_valid_ipn_mock, $this->secret_key, true,
			$this->test_order );
		$this->invalid_ipn_helper_test_class = new Two_Checkout_Ipn_Helper( $this->params_invalid_ipn_mock, $this->secret_key, true,
			$this->test_order );
	}

	public function test_IpnResponse() {
		$this->assertTrue( $this->valid_ipn_helper_test_class->is_ipn_response_valid() );
		$this->assertFalse( $this->invalid_ipn_helper_test_class->is_ipn_response_valid() );
	}

	public function test_generateHash() {
		$this->assertEquals( 'a299fb35e2c113b7d72e8f7afa7ae1f7',
			$this->valid_ipn_helper_test_class->generate_hash( $this->secret_key, 'TestString' ) );
		$this->assertNotEquals( 'NotValid____5e2c113b7d72e8f7afa7ae1f8',
			$this->valid_ipn_helper_test_class->generate_hash( $this->secret_key, 'TestString' ) );
	}

	public function test_process_ipn() {

		// yey reflection
		$method = new ReflectionMethod('Two_Checkout_Ipn_Helper', '_is_fraud');
		if ($method->isProtected() || $method->isPrivate()) {
			$method->setAccessible(true);
		}

		$test_order = $this->getMockBuilder( WC_Order::class )
			->disableOriginalConstructor()
			->getMock()
		;

		$result = $method->invoke(new Two_Checkout_Ipn_Helper(
			$this->params_valid_ipn_mock,
			$this->secret_key,
			true,
			$test_order
		));

		$this->assertSame(false, $result);

		$result = $method->invoke(new Two_Checkout_Ipn_Helper(
			$this->params_valid_ipn_mock_is_fraud,
			$this->secret_key,
			true,
			$test_order
		));

		$this->assertSame(true, $result);
	}

	public function test_is_order_completed() {

		// yey reflection
		$method = new ReflectionMethod('Two_Checkout_Ipn_Helper', '_is_order_completed');
		if ($method->isProtected() || $method->isPrivate()) {
			$method->setAccessible(true);
		}

		$test_order = $this->getMockBuilder( WC_Order::class )
			->disableOriginalConstructor()
			->setMethods( [ 'get_status' ] )
			->getMock()
		;

		$test_order->expects($this->any())
			->method('get_status')
			->willReturn('COMPLETE');

		$result = $method->invoke(new Two_Checkout_Ipn_Helper(
			$this->params_valid_ipn_mock,
			$this->secret_key,
			true,
			$test_order
		));

		$this->assertSame(true, $result);

		$test_order = $this->getMockBuilder( WC_Order::class )
			->disableOriginalConstructor()
			->setMethods( [ 'get_status' ] )
			->getMock()
		;

		$test_order->expects($this->any())
			->method('get_status')
			->willReturn('another_status');

		$result = $method->invoke(new Two_Checkout_Ipn_Helper(
			$this->params_valid_ipn_mock_is_fraud,
			$this->secret_key,
			true,
			$test_order
		));

		$this->assertSame(false, $result);
	}

	public function test_calculate_ipn_response() {

		// yey reflection
		$method = new ReflectionMethod('Two_Checkout_Ipn_Helper', '_calculate_ipn_response');
		if ($method->isProtected() || $method->isPrivate()) {
			$method->setAccessible(true);
		}

		$test_order = $this->getMockBuilder( WC_Order::class )
			->disableOriginalConstructor()
			->getMock()
		;

		$result = $method->invoke(new Two_Checkout_Ipn_Helper(
			$this->params_valid_ipn_mock_is_fraud,
			$this->secret_key,
			true,
			$test_order
		));

		// don't check for the actual response since it's impossible
		$expected = strlen(sprintf('<EPAYMENT>%s|7f409a8a54644a69c974046f91619de6</EPAYMENT>', date( 'YmdHis' )));
		$this->assertSame($expected, strlen($result));
	}

}
