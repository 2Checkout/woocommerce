<?php

require_once __DIR__ . '/../../../../bootstrap.php';

class TwoCheckoutInlineHelperTest extends \WP_Mock\Tools\TestCase {

	public function test_generate_JWT_token() {
		$ipnHelper = new Two_Checkout_Inline_Helper();

		$expected = 'eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjEyMywiaWF0IjoxMjMsImV4cCI6MTIzfQ.IylMsA9uJDTOjjhSCA-S26rcPPJ5j0dQYFBIOeNreGdAV1UNgKxObNIMWE8o2S3EaHDPQ6Kb031S0n5Od46X7g';

		$jwt = $ipnHelper->generate_JWT_token(123, 123, 123, 'test');

		$this->assertSame($expected, $jwt);
	}

}
