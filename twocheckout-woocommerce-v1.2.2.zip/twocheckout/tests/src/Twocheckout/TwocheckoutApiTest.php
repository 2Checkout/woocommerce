<?php
require_once __DIR__ . '/../../../bootstrap.php';

class TwocheckoutApiTest extends \WP_Mock\Tools\TestCase {

	protected $testClass;
	private $secretKey = 'test';
	private $secretWord = 'test';
	private $sellerId = 'test';
	private $demoOrder = 1;
	private $apiUrl = 'https://api.2checkout.com/rest/';
	private $apiVersion = '6.0';

	public function setUp(): void {
		$this->testClass = new Two_Checkout_Api();
	}

	/**
	 * all bellow functions are checked for existence
	 */
	public function testGetSecretKey() {
		$this->testClass->set_secret_key( $this->secretKey );
		$this->assertEquals( $this->secretKey, $this->testClass->get_secret_key() );
	}

	public function testApiUrl() {
		$this->assertEquals( $this->apiUrl, $this->testClass::API_URL );
	}

	public function testApiVersion() {
		$this->assertEquals( $this->apiVersion, $this->testClass::API_VERSION );
	}

	public function testGetSellerId() {
		$this->testClass->set_seller_id( $this->sellerId );
		$this->assertEquals( $this->sellerId, $this->testClass->get_seller_id() );
	}

	public function testGetDemoOrder() {
		$this->testClass->set_test_order( 1 );
		$this->assertEquals( $this->demoOrder, $this->testClass->get_test_order() );
	}

	public function testExistsFunctionCall() {
		$this->expectException( Exception::class );
		$this->assertEquals( Exception::class, $this->testClass->call( '/', [], 'GET' ) );
	}

	public function test_get_headers_exception() {
		$this->expectException( Exception::class );
		$this->testClass->get_headers();
	}

	public function test_get_headers() {
		$gmt_date = gmdate( 'Y-m-d H:i:s' );
		$string   = strlen( 'test' ) . 'test' . strlen( $gmt_date ) . $gmt_date;
		$hash     = hash_hmac( 'md5', $string, 'test' );

		$headers[] = 'Content-Type: application/json';
		$headers[] = 'Accept: application/json';
		$headers[] = 'X-Avangate-Authentication: code="' . 'test' . '" date="' . $gmt_date . '" hash="' . $hash . '"';;

		$this->testClass->set_seller_id( 'test' );
		$this->testClass->set_secret_key( 'test' );
		$result = $this->testClass->get_headers();

		$this->assertEquals($headers, $result);
	}

}
