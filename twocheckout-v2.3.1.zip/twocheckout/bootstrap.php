<?php

require_once '../../../vendor/autoload.php';
WP_Mock::bootstrap();
require_once 'src/Twocheckout/TwoCheckoutApi.php';
require_once 'src/Twocheckout/TwoCheckoutIpnHelperApi.php';
