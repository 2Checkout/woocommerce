<?php

require_once __DIR__ . '/../../../bootstrap.php';

class TwoCheckoutApiTest extends \WP_Mock\Tools\TestCase {
	protected $testClass;
	private $secretKey = 'test';
	private $secretWord = 'test';
	private $sellerId = 'test';
	private $demoOrder = 1;
	private $apiUrl = 'https://api.2checkout.com/rest/';
	private $apiVersion = '6.0';

	public function setUp(): void {
		$this->testClass = new Two_Checkout_Api();
	}

	/**
	 * all bellow functions are checked for existence
	 */
	public function testGetSecretKey() {
		$this->testClass->set_secret_key( $this->secretKey );
		$this->assertEquals( $this->secretKey, $this->testClass->get_secret_key() );
	}

	public function testApiUrl() {
		$this->assertEquals( $this->apiUrl, $this->testClass::API_URL );
	}

	public function testApiVersion() {
		$this->assertEquals( $this->apiVersion, $this->testClass::API_VERSION );
	}

	public function testGetSellerId() {
		$this->testClass->set_seller_id( $this->sellerId );
		$this->assertEquals( $this->sellerId, $this->testClass->get_seller_id() );
	}

	public function testGetDemoOrder() {
		$this->testClass->set_test_order( 1 );
		$this->assertEquals( $this->demoOrder, $this->testClass->get_test_order() );
	}

	public function testExistsFunctionCall() {
		$this->expectException( Exception::class );
		$this->assertEquals( Exception::class, $this->testClass->call( '/', [], 'GET' ) );
	}

	public function test_get_headers_exception() {
		$method = new ReflectionMethod('Two_Checkout_Api', 'get_headers');
		if ($method->isProtected() || $method->isPrivate()) {
			$method->setAccessible(true);
		}
		$this->expectException( Exception::class );
		$method->invoke(new Two_Checkout_Api());
	}

	public function test_get_headers()
	{
		$method = new ReflectionMethod('Two_Checkout_Api', 'get_headers');
		if ($method->isProtected() || $method->isPrivate()) {
			$method->setAccessible(true);
		}

		$testClass = new Two_Checkout_Api();
		$testClass->set_seller_id('test');
		$testClass->set_secret_key('test');

		$gmt_date = gmdate( 'Y-m-d H:i:s' );
		$string   = strlen( 'test' ) . 'test' . strlen( $gmt_date ) . $gmt_date;
		$hash     = hash_hmac( 'sha3-256', $string, 'test' );

		$headers[] = 'Content-Type: application/json';
		$headers[] = 'Accept: application/json';
		$headers[] = 'X-Avangate-Authentication: code="' . 'test' . '" date="' . $gmt_date . '" hash="' . $hash . '" algo="sha3-256"';

		$result = $method->invoke($testClass);

		$this->assertEquals($headers, $result);
	}

	public function test_generate_hash()
	{
		$method = new ReflectionMethod('Two_Checkout_Api', 'generate_hash');
		if ($method->isProtected() || $method->isPrivate()) {
			$method->setAccessible(true);
		}
		$gmt_date = gmdate( 'Y-m-d H:i:s' );
		$result = $method->invokeArgs(new Two_Checkout_Api(), array('test','test', $gmt_date));

		$string = sprintf('%s%s%s%s', strlen('test'), 'test', strlen($gmt_date), $gmt_date);
		$hash = hash_hmac('sha3-256', $string, 'test');

		$this->assertSame($hash, $result);
	}
}
