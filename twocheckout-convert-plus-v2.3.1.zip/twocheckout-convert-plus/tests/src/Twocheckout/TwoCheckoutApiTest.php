<?php

require_once __DIR__ . '/../../../bootstrap.php';

class TwoCheckoutApiTest extends \WP_Mock\Tools\TestCase {
	public function test_getters_setters()
	{
		$testClass = new Two_Checkout_Api();

		$testClass->set_test_order(true);
		$testClass->set_secret_key('test');
		$testClass->set_seller_id('test');
		$this->assertSame('test', $testClass->get_secret_key());
		$this->assertSame('test', $testClass->get_seller_id());
		$this->assertSame(true, $testClass->get_test_order());
	}

	public function test_get_headers_exception()
	{
		$method = new ReflectionMethod('Two_Checkout_Api', 'get_headers');
		if ($method->isProtected() || $method->isPrivate()) {
			$method->setAccessible(true);
		}

		$this->expectException(Exception::class);
		$method->invoke(new Two_Checkout_Api());
	}

	public function test_get_headers()
	{
		$method = new ReflectionMethod('Two_Checkout_Api', 'get_headers');
		if ($method->isProtected() || $method->isPrivate()) {
			$method->setAccessible(true);
		}

		$testClass = new Two_Checkout_Api();
		$testClass->set_seller_id('test');
		$testClass->set_secret_key('test');

		$gmt_date = gmdate( 'Y-m-d H:i:s' );
		$string   = strlen( 'test' ) . 'test' . strlen( $gmt_date ) . $gmt_date;
		$hash     = hash_hmac( 'sha3-256', $string, 'test' );

		$headers[] = 'Content-Type: application/json';
		$headers[] = 'Accept: application/json';
		$headers[] = 'X-Avangate-Authentication: code="' . 'test' . '" date="' . $gmt_date . '" hash="' . $hash . '" algo="sha3-256"';

		$result = $method->invoke($testClass);

		$this->assertEquals($headers, $result);
	}

	public function test_generate_hash()
	{
		$method = new ReflectionMethod('Two_Checkout_Api', 'generate_hash');
		if ($method->isProtected() || $method->isPrivate()) {
			$method->setAccessible(true);
		}
		$gmt_date = gmdate( 'Y-m-d H:i:s' );
		$result = $method->invokeArgs(new Two_Checkout_Api(), array('test','test', $gmt_date));

		$string = sprintf('%s%s%s%s', strlen('test'), 'test', strlen($gmt_date), $gmt_date);
		$hash = hash_hmac('sha3-256', $string, 'test');

		$this->assertSame($hash, $result);
	}
}
